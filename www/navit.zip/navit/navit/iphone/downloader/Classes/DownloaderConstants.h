/*
 *  DownloaderConstants.h
 *  Downloader
 *
 *  Created by Nick Geoghegan on 09/08/2011.
 *  Copyright 2011 Navit Project. All rights reserved.
 *
 */

#define NAME_KEY		@"name"
#define BOUNDING_BOX	@"bbox"
