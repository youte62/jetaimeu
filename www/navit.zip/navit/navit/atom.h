#ifdef __cplusplus
extern "C" {
#endif
char * atom_lookup(char *name);
char * atom(char *name);
void atom_init(void);
#ifdef __cplusplus
}
#endif
