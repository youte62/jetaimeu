#include "../../plugin.h"

void
plugin_init(void)
{
}
