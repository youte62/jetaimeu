void gui_internal_html_main_menu(struct gui_priv *this);
void gui_internal_html_load_href(struct gui_priv *this, char *href, int replace);
void gui_internal_html_href(struct gui_priv *this, struct widget *w, void *data);
void gui_internal_html_parse_text(struct gui_priv *this, char *doc);
void gui_internal_html_menu(struct gui_priv *this, const char *document, char *anchor);
