char * get_icon(struct navit *nav, struct item *item);
