/* prototypes */
void event_glib_init(void);
/* end of prototypes */
