#include <windows.h>

#define IDI_NAVIT 1100
#define IDB_NAVITTOOLBAR 1101
