git clone https://github.com/navit-gps/navit.git
cd navit
bash ci/build_tomtom_minimal.sh
