apt-get update && apt-get install -y wget unzip cmake build-essential gettext
